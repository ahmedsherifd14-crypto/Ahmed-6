#include "ERDRoutingSubsystem.h"
#include "HttpModule.h"
#include "Interfaces/IHttpResponse.h"
#include "Dom/JsonObject.h"
#include "Dom/JsonValue.h"
#include "Serialization/JsonReader.h"
#include "Serialization/JsonSerializer.h"

static double HaversineM(double Lon1, double Lat1, double Lon2, double Lat2)
{
	const double R = 6371000.0;
	const double P1 = FMath::DegreesToRadians(Lat1);
	const double P2 = FMath::DegreesToRadians(Lat2);
	const double DP = P2 - P1;
	const double DL = FMath::DegreesToRadians(Lon2 - Lon1);
	const double S1 = FMath::Sin(DP * 0.5);
	const double S2 = FMath::Sin(DL * 0.5);
	const double A = S1 * S1 + FMath::Cos(P1) * FMath::Cos(P2) * S2 * S2;
	return 2.0 * R * FMath::Asin(FMath::Min(1.0, FMath::Sqrt(A)));
}

const TArray<FERDDestination>& UERDRoutingSubsystem::GetDestinations()
{
	// Approximate city-centre coordinates (WGS84). Press keys 1..0 in game to route to them.
	static TArray<FERDDestination> List;
	if (List.Num() == 0)
	{
		auto Add = [&](const TCHAR* N, double Lon, double Lat)
		{
			FERDDestination D; D.Name = N; D.Lon = Lon; D.Lat = Lat; List.Add(D);
		};
		Add(TEXT("Cairo (Downtown)"),        31.2357, 30.0444);
		Add(TEXT("Giza (Pyramids)"),         31.1342, 29.9792);
		Add(TEXT("Alexandria"),              29.9187, 31.2001);
		Add(TEXT("New Cairo"),               31.4913, 30.0074);
		Add(TEXT("6th of October City"),     30.9259, 29.9285);
		Add(TEXT("Sharm El Sheikh"),         34.3300, 27.9158);
		Add(TEXT("Hurghada"),                33.8116, 27.2579);
		Add(TEXT("Luxor"),                   32.6396, 25.6872);
		Add(TEXT("Aswan"),                   32.8998, 24.0889);
		Add(TEXT("North Coast (El Alamein)"),28.9546, 30.8305);
	}
	return List;
}

void UERDRoutingSubsystem::StartRouteToDestination(int32 DestinationIndex)
{
	const TArray<FERDDestination>& D = GetDestinations();
	if (!D.IsValidIndex(DestinationIndex)) return;
	DestinationName = D[DestinationIndex].Name;
	RequestRoute(PlayerLon, PlayerLat, D[DestinationIndex].Lon, D[DestinationIndex].Lat);
}

void UERDRoutingSubsystem::CancelRoute()
{
	bHasRoute = false; bArrived = false;
	RoutePoints.Reset(); CumulativeM.Reset(); Steps.Reset();
	DestinationName.Reset(); NextTurnText.Reset(); StatusText.Reset();
	RemainingDistanceM = RemainingTimeS = DistanceToNextTurnM = 0.0;
}

void UERDRoutingSubsystem::RequestRoute(double FromLon, double FromLat, double ToLon, double ToLat)
{
	if (bRequestInFlight) return;
	DestLon = ToLon; DestLat = ToLat;
	bArrived = false;

	const FString Url = FString::Printf(
		TEXT("%s/route/v1/driving/%.6f,%.6f;%.6f,%.6f?overview=full&geometries=geojson&steps=true"),
		*ServerUrl, FromLon, FromLat, ToLon, ToLat);

	TSharedRef<IHttpRequest, ESPMode::ThreadSafe> Req = FHttpModule::Get().CreateRequest();
	Req->SetURL(Url);
	Req->SetVerb(TEXT("GET"));
	Req->OnProcessRequestComplete().BindUObject(this, &UERDRoutingSubsystem::OnRouteResponse);
	bRequestInFlight = true;
	LastRequestTime = FPlatformTime::Seconds();
	StatusText = TEXT("Calculating route...");
	Req->ProcessRequest();
}

FString UERDRoutingSubsystem::BuildInstruction(const FString& Type, const FString& Modifier, const FString& Name, int32 Exit)
{
	if (Type == TEXT("arrive")) return TEXT("You have arrived");
	if (Type == TEXT("roundabout") || Type == TEXT("rotary") || Type == TEXT("roundabout turn"))
	{
		return Exit > 0 ? FString::Printf(TEXT("At the roundabout take exit %d"), Exit) : FString(TEXT("Enter the roundabout"));
	}
	FString Action;
	if (Type == TEXT("depart")) Action = TEXT("Head out");
	else if (Type == TEXT("merge")) Action = TEXT("Merge");
	else if (Type == TEXT("on ramp")) Action = TEXT("Take the ramp");
	else if (Type == TEXT("off ramp")) Action = TEXT("Take the exit");
	else if (Type == TEXT("fork")) Action = TEXT("Keep");
	else if (Modifier == TEXT("uturn")) Action = TEXT("Make a U-turn");
	else if (Modifier == TEXT("straight") || Modifier.IsEmpty()) Action = TEXT("Continue straight");
	else Action = FString::Printf(TEXT("Turn %s"), *Modifier);

	if (Modifier != TEXT("uturn") && (Type == TEXT("merge") || Type == TEXT("on ramp") || Type == TEXT("off ramp") || Type == TEXT("fork")) && !Modifier.IsEmpty())
	{
		Action += TEXT(" ") + Modifier;
	}
	return Name.IsEmpty() ? Action : FString::Printf(TEXT("%s onto %s"), *Action, *Name);
}

void UERDRoutingSubsystem::OnRouteResponse(FHttpRequestPtr, FHttpResponsePtr Response, bool bOk)
{
	bRequestInFlight = false;
	if (!bOk || !Response.IsValid() || Response->GetResponseCode() != 200)
	{
		StatusText = TEXT("Routing service unreachable");
		return;
	}

	TSharedPtr<FJsonObject> Root;
	TSharedRef<TJsonReader<>> Reader = TJsonReaderFactory<>::Create(Response->GetContentAsString());
	if (!FJsonSerializer::Deserialize(Reader, Root) || !Root.IsValid()) { StatusText = TEXT("Bad route data"); return; }

	const TArray<TSharedPtr<FJsonValue>>* Routes = nullptr;
	if (!Root->TryGetArrayField(TEXT("routes"), Routes) || Routes->Num() == 0) { StatusText = TEXT("No road route found"); return; }

	const TSharedPtr<FJsonObject> R = (*Routes)[0]->AsObject();
	TotalDistanceM = R->GetNumberField(TEXT("distance"));
	TotalDurationS = R->GetNumberField(TEXT("duration"));

	RoutePoints.Reset(); CumulativeM.Reset(); Steps.Reset();

	const TSharedPtr<FJsonObject> Geom = R->GetObjectField(TEXT("geometry"));
	const TArray<TSharedPtr<FJsonValue>>* Coords = nullptr;
	if (!Geom->TryGetArrayField(TEXT("coordinates"), Coords)) { StatusText = TEXT("Bad route geometry"); return; }

	double Acc = 0.0;
	for (int32 i = 0; i < Coords->Num(); ++i)
	{
		const TArray<TSharedPtr<FJsonValue>>& C = (*Coords)[i]->AsArray();
		if (C.Num() < 2) continue;
		const FVector2D P(C[0]->AsNumber(), C[1]->AsNumber());
		if (RoutePoints.Num() > 0)
		{
			const FVector2D& Q = RoutePoints.Last();
			Acc += HaversineM(Q.X, Q.Y, P.X, P.Y);
		}
		RoutePoints.Add(P);
		CumulativeM.Add(Acc);
	}

	// Turn list: each step's end is where the NEXT step's maneuver happens.
	const TArray<TSharedPtr<FJsonValue>>* Legs = nullptr;
	if (R->TryGetArrayField(TEXT("legs"), Legs) && Legs->Num() > 0)
	{
		const TArray<TSharedPtr<FJsonValue>>* StepArr = nullptr;
		if ((*Legs)[0]->AsObject()->TryGetArrayField(TEXT("steps"), StepArr))
		{
			double StepAcc = 0.0;
			for (int32 i = 0; i < StepArr->Num(); ++i)
			{
				const TSharedPtr<FJsonObject> S = (*StepArr)[i]->AsObject();
				StepAcc += S->GetNumberField(TEXT("distance"));

				FERDRouteStep Out;
				Out.EndAlongM = StepAcc;
				if (StepArr->IsValidIndex(i + 1))
				{
					const TSharedPtr<FJsonObject> Next = (*StepArr)[i + 1]->AsObject();
					const TSharedPtr<FJsonObject> M = Next->GetObjectField(TEXT("maneuver"));
					FString Type, Mod;
					M->TryGetStringField(TEXT("type"), Type);
					M->TryGetStringField(TEXT("modifier"), Mod);
					int32 Exit = 0; M->TryGetNumberField(TEXT("exit"), Exit);
					FString Name; Next->TryGetStringField(TEXT("name"), Name);
					Out.NextInstruction = BuildInstruction(Type, Mod, Name, Exit);
				}
				else
				{
					Out.NextInstruction = TEXT("You have arrived");
				}
				Steps.Add(Out);
			}
		}
	}

	NearestIdx = 0;
	bHasRoute = RoutePoints.Num() > 1;
	StatusText = bHasRoute ? TEXT("") : TEXT("No road route found");
	UpdatePlayerPosition(PlayerLon, PlayerLat);
}

void UERDRoutingSubsystem::UpdatePlayerPosition(double Lon, double Lat)
{
	PlayerLon = Lon; PlayerLat = Lat;
	if (!bHasRoute || RoutePoints.Num() < 2 || bArrived) return;

	// Nearest route point: search a forward window first, full search if we are far from it.
	auto Search = [&](int32 From, int32 To, double& BestD) -> int32
	{
		int32 Best = From; BestD = TNumericLimits<double>::Max();
		for (int32 i = From; i < To; ++i)
		{
			const double D = HaversineM(Lon, Lat, RoutePoints[i].X, RoutePoints[i].Y);
			if (D < BestD) { BestD = D; Best = i; }
		}
		return Best;
	};

	double BestD = 0.0;
	int32 Idx = Search(NearestIdx, FMath::Min(NearestIdx + 400, RoutePoints.Num()), BestD);
	if (BestD > 150.0) Idx = Search(0, RoutePoints.Num(), BestD);
	NearestIdx = Idx;

	const double Progress = CumulativeM[NearestIdx];
	RemainingDistanceM = FMath::Max(0.0, CumulativeM.Last() - Progress);
	RemainingTimeS = TotalDistanceM > 1.0 ? TotalDurationS * (RemainingDistanceM / CumulativeM.Last()) : 0.0;

	// Next maneuver
	NextTurnText = TEXT("Follow the route");
	DistanceToNextTurnM = RemainingDistanceM;
	for (const FERDRouteStep& S : Steps)
	{
		if (S.EndAlongM > Progress + 1.0)
		{
			NextTurnText = S.NextInstruction;
			DistanceToNextTurnM = S.EndAlongM - Progress;
			break;
		}
	}

	// Arrival
	if (RemainingDistanceM < 30.0)
	{
		bArrived = true; bHasRoute = false;
		NextTurnText = TEXT("You have arrived"); StatusText = TEXT("Arrived at ") + DestinationName;
		return;
	}

	// Re-route if we left the road we were told to take
	if (BestD > OffRouteThresholdM && !bRequestInFlight && (FPlatformTime::Seconds() - LastRequestTime) > 5.0)
	{
		StatusText = TEXT("Re-routing...");
		RequestRoute(Lon, Lat, DestLon, DestLat);
	}
}
