#pragma once

#include "CoreMinimal.h"
#include "GameFramework/SaveGame.h"
#include "ERDSaveGame.generated.h"

UCLASS()
class EGYPTREALDRIVE_API UERDSaveGame : public USaveGame
{
	GENERATED_BODY()
public:
	UPROPERTY() double Lon = 0.0;
	UPROPERTY() double Lat = 0.0;
	UPROPERTY() double Height = 0.0;
	UPROPERTY() float Yaw = 0.f;
	UPROPERTY() float Fuel = 50.f;
	UPROPERTY() int32 SelectedCarIndex = 0;
	UPROPERTY() FLinearColor PaintColor = FLinearColor::White;
	UPROPERTY() double DestLon = 0.0;
	UPROPERTY() double DestLat = 0.0;
	UPROPERTY() FString DestName;
	UPROPERTY() bool bHasDestination = false;

	static FString SlotName() { return TEXT("ERD_Slot0"); }
};
