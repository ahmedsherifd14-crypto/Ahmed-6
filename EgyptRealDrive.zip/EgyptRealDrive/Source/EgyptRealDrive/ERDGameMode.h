#pragma once

#include "CoreMinimal.h"
#include "GameFramework/GameModeBase.h"
#include "ERDGameMode.generated.h"

UCLASS()
class EGYPTREALDRIVE_API AERDGameMode : public AGameModeBase
{
	GENERATED_BODY()
public:
	AERDGameMode();
};
