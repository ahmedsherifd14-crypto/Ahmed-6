#pragma once

#include "CoreMinimal.h"
#include "GameFramework/HUD.h"
#include "ERDHUD.generated.h"

/** Canvas-drawn driving HUD + GPS panel + route mini-map. No asset dependencies. */
UCLASS()
class EGYPTREALDRIVE_API AERDHUD : public AHUD
{
	GENERATED_BODY()
public:
	virtual void DrawHUD() override;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="HUD") float MiniMapRangeM = 1500.f;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="HUD") float MiniMapSizePx = 280.f;
};
