using UnrealBuildTool;

public class EgyptRealDrive : ModuleRules
{
	public EgyptRealDrive(ReadOnlyTargetRules Target) : base(Target)
	{
		PCHUsage = PCHUsageMode.UseExplicitOrSharedPCHs;

		PublicDependencyModuleNames.AddRange(new string[] {
			"Core", "CoreUObject", "Engine", "InputCore",
			"PhysicsCore", "ChaosVehicles",
			"HTTP", "Json", "JsonUtilities",
			"CesiumRuntime"
		});
	}
}
