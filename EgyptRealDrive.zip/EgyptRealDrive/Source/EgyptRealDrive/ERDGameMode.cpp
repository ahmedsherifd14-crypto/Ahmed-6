#include "ERDGameMode.h"
#include "ERDVehiclePawn.h"
#include "ERDHUD.h"

AERDGameMode::AERDGameMode()
{
	// Replace DefaultPawnClass with your BP_ERDVehicle child in a Blueprint game mode (BP_ERDGameMode).
	DefaultPawnClass = AERDVehiclePawn::StaticClass();
	HUDClass = AERDHUD::StaticClass();
}
