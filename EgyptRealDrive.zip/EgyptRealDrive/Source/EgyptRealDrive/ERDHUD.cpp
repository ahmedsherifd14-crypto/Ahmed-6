#include "ERDHUD.h"
#include "ERDVehiclePawn.h"
#include "ERDRoutingSubsystem.h"
#include "Engine/Canvas.h"
#include "Engine/Engine.h"
#include "Engine/Font.h"

void AERDHUD::DrawHUD()
{
	Super::DrawHUD();
	if (!Canvas) return;

	UFont* Big = GEngine->GetLargeFont();
	UFont* Med = GEngine->GetMediumFont();
	const float W = Canvas->SizeX, H = Canvas->SizeY;

	// ---------- Speed / RPM / Gear / Fuel ----------
	if (const AERDVehiclePawn* Car = Cast<AERDVehiclePawn>(GetOwningPawn()))
	{
		const float BaseX = 40.f, BaseY = H - 200.f;
		DrawRect(FLinearColor(0, 0, 0, 0.45f), BaseX - 15, BaseY - 15, 360, 190);

		DrawText(FString::Printf(TEXT("%d"), FMath::RoundToInt(Car->GetSpeedKmh())), FLinearColor::White, BaseX, BaseY, Big, 3.0f);
		DrawText(TEXT("km/h"), FLinearColor(0.8f, 0.8f, 0.8f), BaseX + 170, BaseY + 50, Med, 1.0f);

		const int32 G = Car->GetGear();
		const FString GearStr = G < 0 ? TEXT("R") : (G == 0 ? TEXT("N") : FString::FromInt(G));
		DrawText(FString::Printf(TEXT("%s  %s"), *GearStr, Car->bAutomatic ? TEXT("AUTO") : TEXT("MANUAL")),
			FLinearColor::Yellow, BaseX, BaseY + 80, Big, 1.2f);

		// RPM bar
		const float RPMFrac = FMath::Clamp(Car->GetRPM() / FMath::Max(1.f, Car->MaxRPM), 0.f, 1.f);
		DrawRect(FLinearColor(0.2f, 0.2f, 0.2f, 0.9f), BaseX, BaseY + 125, 330, 12);
		DrawRect(RPMFrac > 0.85f ? FLinearColor::Red : FLinearColor::Green, BaseX, BaseY + 125, 330 * RPMFrac, 12);
		DrawText(FString::Printf(TEXT("%d RPM"), FMath::RoundToInt(Car->GetRPM())), FLinearColor::White, BaseX, BaseY + 140, Med, 0.9f);

		// Fuel bar
		const float FuelFrac = Car->FuelCapacityL > 0 ? Car->Fuel / Car->FuelCapacityL : 0.f;
		DrawRect(FLinearColor(0.2f, 0.2f, 0.2f, 0.9f), BaseX + 170, BaseY + 140, 160, 10);
		DrawRect(FuelFrac < 0.15f ? FLinearColor::Red : FLinearColor(1, 0.7f, 0, 1), BaseX + 170, BaseY + 140, 160 * FuelFrac, 10);
		DrawText(FString::Printf(TEXT("Fuel %.1f L"), Car->Fuel), FLinearColor::White, BaseX + 170, BaseY + 105, Med, 0.9f);
	}

	// ---------- GPS ----------
	UERDRoutingSubsystem* R = GetGameInstance() ? GetGameInstance()->GetSubsystem<UERDRoutingSubsystem>() : nullptr;
	if (!R) return;

	const float PX = 30.f, PY = 30.f;
	DrawRect(FLinearColor(0, 0, 0, 0.55f), PX - 10, PY - 10, 520, 170);
	DrawText(FString::Printf(TEXT("GPS   %.5f, %.5f"), R->PlayerLat, R->PlayerLon), FLinearColor(0.6f, 0.9f, 1.f), PX, PY, Med, 1.0f);

	if (R->bHasRoute)
	{
		const double D = R->DistanceToNextTurnM;
		const FString DistStr = D >= 1000 ? FString::Printf(TEXT("%.1f km"), D / 1000.0) : FString::Printf(TEXT("%d m"), (int32)(FMath::RoundToInt(D / 10.0) * 10));
		DrawText(FString::Printf(TEXT("In %s: %s"), *DistStr, *R->NextTurnText), FLinearColor::White, PX, PY + 30, Big, 1.0f);

		const int32 Mins = FMath::CeilToInt(R->RemainingTimeS / 60.0);
		DrawText(FString::Printf(TEXT("To %s: %.1f km   %d h %02d min"), *R->DestinationName, R->RemainingDistanceM / 1000.0, Mins / 60, Mins % 60),
			FLinearColor::Yellow, PX, PY + 75, Med, 1.0f);
	}
	else
	{
		const FString Msg = !R->StatusText.IsEmpty() ? R->StatusText : TEXT("Press 1-9,0 to pick a destination (X cancels)");
		DrawText(Msg, FLinearColor::White, PX, PY + 35, Med, 1.0f);
	}

	// Destination list hint
	const TArray<FERDDestination>& Dest = UERDRoutingSubsystem::GetDestinations();
	float Y = PY + 110;
	FString Line;
	for (int32 i = 0; i < Dest.Num(); ++i) Line += FString::Printf(TEXT("%d:%s  "), (i + 1) % 10, *Dest[i].Name.Left(8));
	DrawText(Line, FLinearColor(0.7f, 0.7f, 0.7f), PX, Y, nullptr, 0.7f);

	// ---------- Route mini-map (north up) ----------
	if (R->bHasRoute && R->RoutePoints.Num() > 1)
	{
		const float S = MiniMapSizePx;
		const float CX = W - S * 0.5f - 30.f, CY = S * 0.5f + 30.f;
		DrawRect(FLinearColor(0, 0, 0, 0.55f), CX - S * 0.5f, CY - S * 0.5f, S, S);

		const double CosLat = FMath::Cos(FMath::DegreesToRadians(R->PlayerLat));
		auto ToPx = [&](const FVector2D& P) -> FVector2D
		{
			const double Dx = (P.X - R->PlayerLon) * 111320.0 * CosLat;
			const double Dy = (P.Y - R->PlayerLat) * 110574.0;
			return FVector2D(CX + Dx / MiniMapRangeM * (S * 0.5), CY - Dy / MiniMapRangeM * (S * 0.5));
		};
		auto Inside = [&](const FVector2D& P) { return FMath::Abs(P.X - CX) < S * 0.5f && FMath::Abs(P.Y - CY) < S * 0.5f; };

		for (int32 i = 1; i < R->RoutePoints.Num(); ++i)
		{
			const FVector2D A = ToPx(R->RoutePoints[i - 1]), B = ToPx(R->RoutePoints[i]);
			if (Inside(A) && Inside(B)) DrawLine(A.X, A.Y, B.X, B.Y, FLinearColor(0.2f, 0.7f, 1.f), 4.f);
		}
		DrawRect(FLinearColor::Red, CX - 5, CY - 5, 10, 10);
	}
}
