#pragma once

#include "CoreMinimal.h"
#include "Subsystems/GameInstanceSubsystem.h"
#include "Interfaces/IHttpRequest.h"
#include "ERDRoutingSubsystem.generated.h"

USTRUCT(BlueprintType)
struct FERDDestination
{
	GENERATED_BODY()
	UPROPERTY(BlueprintReadOnly) FString Name;
	UPROPERTY(BlueprintReadOnly) double Lon = 0.0;
	UPROPERTY(BlueprintReadOnly) double Lat = 0.0;
};

struct FERDRouteStep
{
	double EndAlongM = 0.0;     // distance along the route where this step ends (= where the next maneuver happens)
	FString NextInstruction;    // text of the maneuver at the end of this step
};

/**
 * Real-road routing. Calls an OSRM-compatible HTTP service (OpenStreetMap data),
 * keeps the route polyline + turn list, and updates progress / ETA / re-routing
 * as the player position changes.
 */
UCLASS()
class EGYPTREALDRIVE_API UERDRoutingSubsystem : public UGameInstanceSubsystem
{
	GENERATED_BODY()

public:
	/** OSRM base URL. The public demo server is for testing only - self-host OSRM (Egypt extract from Geofabrik) for a shipped game. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="GPS")
	FString ServerUrl = TEXT("https://router.project-osrm.org");

	/** Re-route when the player is further than this from the route (meters). */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="GPS")
	double OffRouteThresholdM = 60.0;

	static const TArray<FERDDestination>& GetDestinations();

	UFUNCTION(BlueprintCallable, Category="GPS") void RequestRoute(double FromLon, double FromLat, double ToLon, double ToLat);
	UFUNCTION(BlueprintCallable, Category="GPS") void StartRouteToDestination(int32 DestinationIndex);
	UFUNCTION(BlueprintCallable, Category="GPS") void CancelRoute();
	UFUNCTION(BlueprintCallable, Category="GPS") void UpdatePlayerPosition(double Lon, double Lat);

	// ---- State read by the HUD / Blueprints ----
	UPROPERTY(BlueprintReadOnly, Category="GPS") bool bHasRoute = false;
	UPROPERTY(BlueprintReadOnly, Category="GPS") bool bRequestInFlight = false;
	UPROPERTY(BlueprintReadOnly, Category="GPS") FString DestinationName;
	UPROPERTY(BlueprintReadOnly, Category="GPS") FString StatusText;
	UPROPERTY(BlueprintReadOnly, Category="GPS") double PlayerLon = 0.0;
	UPROPERTY(BlueprintReadOnly, Category="GPS") double PlayerLat = 0.0;
	UPROPERTY(BlueprintReadOnly, Category="GPS") double TotalDistanceM = 0.0;
	UPROPERTY(BlueprintReadOnly, Category="GPS") double RemainingDistanceM = 0.0;
	UPROPERTY(BlueprintReadOnly, Category="GPS") double RemainingTimeS = 0.0;
	UPROPERTY(BlueprintReadOnly, Category="GPS") double DistanceToNextTurnM = 0.0;
	UPROPERTY(BlueprintReadOnly, Category="GPS") FString NextTurnText;
	UPROPERTY(BlueprintReadOnly, Category="GPS") bool bArrived = false;

	/** Route polyline as (lon, lat). Used by the HUD mini-map. */
	TArray<FVector2D> RoutePoints;

private:
	void OnRouteResponse(FHttpRequestPtr Request, FHttpResponsePtr Response, bool bOk);
	static FString BuildInstruction(const FString& Type, const FString& Modifier, const FString& Name, int32 Exit);

	TArray<double> CumulativeM;       // cumulative distance at each RoutePoints[i]
	TArray<FERDRouteStep> Steps;
	int32 NearestIdx = 0;
	double DestLon = 0.0, DestLat = 0.0;
	double TotalDurationS = 0.0;
	double LastRequestTime = -100.0;
};
