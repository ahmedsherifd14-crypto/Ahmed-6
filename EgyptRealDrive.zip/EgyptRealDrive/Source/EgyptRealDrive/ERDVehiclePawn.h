#pragma once

#include "CoreMinimal.h"
#include "WheeledVehiclePawn.h"
#include "ERDVehiclePawn.generated.h"

class USpringArmComponent;
class UCameraComponent;
class UChaosWheeledVehicleMovementComponent;

DECLARE_DELEGATE_OneParam(FERDSelectDestination, int32);

/**
 * Drivable car. Make a Blueprint child (BP_ERDVehicle), assign the skeletal mesh,
 * physics asset, animation BP and the 4 wheel classes/bones in the movement component.
 * Every real car = one BP child with its own engine/gear/mass/suspension values.
 */
UCLASS()
class EGYPTREALDRIVE_API AERDVehiclePawn : public AWheeledVehiclePawn
{
	GENERATED_BODY()

public:
	AERDVehiclePawn(const FObjectInitializer& ObjectInitializer);

	virtual void Tick(float DeltaSeconds) override;
	virtual void BeginPlay() override;
	virtual void SetupPlayerInputComponent(UInputComponent* PlayerInputComponent) override;

	// ---- Components ----
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category="Camera") TObjectPtr<USpringArmComponent> SpringArm;
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category="Camera") TObjectPtr<UCameraComponent> ChaseCamera;
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category="Camera") TObjectPtr<UCameraComponent> CockpitCamera;

	// ---- Gameplay values (per car, set in the BP child) ----
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Car") FString CarDisplayName = TEXT("Car");
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Car") float FuelCapacityL = 50.f;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Car") float IdleBurnLPerSec = 0.0003f;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Car") float FullLoadBurnLPerSec = 0.0035f;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Car") float MaxRPM = 7000.f;

	UPROPERTY(BlueprintReadOnly, Category="Car") float Fuel = 50.f;
	UPROPERTY(BlueprintReadOnly, Category="Car") bool bCockpitView = false;
	UPROPERTY(BlueprintReadOnly, Category="Car") bool bAutomatic = true;

	UFUNCTION(BlueprintPure, Category="Car") float GetSpeedKmh() const;
	UFUNCTION(BlueprintPure, Category="Car") float GetRPM() const;
	UFUNCTION(BlueprintPure, Category="Car") int32 GetGear() const;

	UFUNCTION(BlueprintCallable, Category="Car") void SetCockpitView(bool bCockpit);
	UFUNCTION(BlueprintCallable, Category="Car") void SetPaintColor(FLinearColor Color);
	UFUNCTION(BlueprintCallable, Category="Save") void SaveProgress();
	UFUNCTION(BlueprintCallable, Category="Save") void LoadProgress();

	/** Name of the material parameter (vector) that drives body paint in your car material. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Car") FName PaintParameterName = TEXT("BodyColor");
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Car") int32 PaintMaterialSlot = 0;

private:
	UChaosWheeledVehicleMovementComponent* Mov() const;

	void Throttle(float V);
	void Brake(float V);
	void Steer(float V);
	void HandbrakeOn();
	void HandbrakeOff();
	void ToggleCamera();
	void ToggleGearbox();
	void ShiftUp();
	void ShiftDown();
	void Refuel();
	void CancelRoute();
	void SelectDestination(int32 Index);

	float ThrottleInput = 0.f;
	float PosTimer = 0.f;
	FLinearColor CurrentPaint = FLinearColor::White;
	int32 SelectedCarIndex = 0;
};
