#include "ERDVehiclePawn.h"
#include "ERDRoutingSubsystem.h"
#include "ERDSaveGame.h"
#include "ChaosWheeledVehicleMovementComponent.h"
#include "Camera/CameraComponent.h"
#include "GameFramework/SpringArmComponent.h"
#include "Components/InputComponent.h"
#include "Components/SkeletalMeshComponent.h"
#include "Kismet/GameplayStatics.h"
#include "Materials/MaterialInstanceDynamic.h"
#include "CesiumGeoreference.h"

AERDVehiclePawn::AERDVehiclePawn(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
	PrimaryActorTick.bCanEverTick = true;

	SpringArm = CreateDefaultSubobject<USpringArmComponent>(TEXT("SpringArm"));
	SpringArm->SetupAttachment(GetMesh());
	SpringArm->TargetArmLength = 650.f;
	SpringArm->SocketOffset = FVector(0.f, 0.f, 170.f);
	SpringArm->bEnableCameraLag = true;
	SpringArm->CameraLagSpeed = 6.f;
	SpringArm->bInheritPitch = false;
	SpringArm->bInheritRoll = false;

	ChaseCamera = CreateDefaultSubobject<UCameraComponent>(TEXT("ChaseCamera"));
	ChaseCamera->SetupAttachment(SpringArm, USpringArmComponent::SocketName);

	// Left-hand-drive driver's eye position (Y negative = left). Adjust per car in the BP.
	CockpitCamera = CreateDefaultSubobject<UCameraComponent>(TEXT("CockpitCamera"));
	CockpitCamera->SetupAttachment(GetMesh());
	CockpitCamera->SetRelativeLocation(FVector(5.f, -35.f, 115.f));
	CockpitCamera->bUsePawnControlRotation = false;
	CockpitCamera->SetAutoActivate(false);
}

UChaosWheeledVehicleMovementComponent* AERDVehiclePawn::Mov() const
{
	return Cast<UChaosWheeledVehicleMovementComponent>(GetVehicleMovementComponent());
}

void AERDVehiclePawn::BeginPlay()
{
	Super::BeginPlay();
	Fuel = FuelCapacityL;
	if (UChaosWheeledVehicleMovementComponent* M = Mov()) M->SetUseAutomaticGears(true);
	SetCockpitView(false);
}

void AERDVehiclePawn::SetupPlayerInputComponent(UInputComponent* PIC)
{
	Super::SetupPlayerInputComponent(PIC);

	PIC->BindAxis("Throttle", this, &AERDVehiclePawn::Throttle);
	PIC->BindAxis("Brake", this, &AERDVehiclePawn::Brake);
	PIC->BindAxis("Steer", this, &AERDVehiclePawn::Steer);
	PIC->BindAction("Handbrake", IE_Pressed, this, &AERDVehiclePawn::HandbrakeOn);
	PIC->BindAction("Handbrake", IE_Released, this, &AERDVehiclePawn::HandbrakeOff);
	PIC->BindAction("ToggleCamera", IE_Pressed, this, &AERDVehiclePawn::ToggleCamera);
	PIC->BindAction("ToggleGearbox", IE_Pressed, this, &AERDVehiclePawn::ToggleGearbox);
	PIC->BindAction("ShiftUp", IE_Pressed, this, &AERDVehiclePawn::ShiftUp);
	PIC->BindAction("ShiftDown", IE_Pressed, this, &AERDVehiclePawn::ShiftDown);
	PIC->BindAction("Refuel", IE_Pressed, this, &AERDVehiclePawn::Refuel);
	PIC->BindAction("CancelRoute", IE_Pressed, this, &AERDVehiclePawn::CancelRoute);
	PIC->BindAction("SaveGame", IE_Pressed, this, &AERDVehiclePawn::SaveProgress);
	PIC->BindAction("LoadGame", IE_Pressed, this, &AERDVehiclePawn::LoadProgress);

	for (int32 i = 0; i < 10; ++i)
	{
		PIC->BindAction<FERDSelectDestination>(FName(*FString::Printf(TEXT("Dest%d"), i)), IE_Pressed, this,
			&AERDVehiclePawn::SelectDestination, i);
	}
}

// ---------------- Input ----------------
void AERDVehiclePawn::Throttle(float V)
{
	ThrottleInput = (Fuel > 0.f) ? V : 0.f;
	if (UChaosWheeledVehicleMovementComponent* M = Mov()) M->SetThrottleInput(ThrottleInput);
}
void AERDVehiclePawn::Brake(float V)  { if (auto* M = Mov()) M->SetBrakeInput(V); }
void AERDVehiclePawn::Steer(float V)  { if (auto* M = Mov()) M->SetSteeringInput(V); }
void AERDVehiclePawn::HandbrakeOn()   { if (auto* M = Mov()) M->SetHandbrakeInput(true); }
void AERDVehiclePawn::HandbrakeOff()  { if (auto* M = Mov()) M->SetHandbrakeInput(false); }
void AERDVehiclePawn::ToggleCamera()  { SetCockpitView(!bCockpitView); }
void AERDVehiclePawn::Refuel()        { Fuel = FuelCapacityL; }

void AERDVehiclePawn::ToggleGearbox()
{
	bAutomatic = !bAutomatic;
	if (auto* M = Mov()) M->SetUseAutomaticGears(bAutomatic);
}
void AERDVehiclePawn::ShiftUp()
{
	if (bAutomatic) return;
	if (auto* M = Mov()) M->SetTargetGear(M->GetTargetGear() + 1, true);
}
void AERDVehiclePawn::ShiftDown()
{
	if (bAutomatic) return;
	if (auto* M = Mov()) M->SetTargetGear(M->GetTargetGear() - 1, true); // -1 = reverse
}

void AERDVehiclePawn::SetCockpitView(bool bCockpit)
{
	bCockpitView = bCockpit;
	CockpitCamera->SetActive(bCockpit);
	ChaseCamera->SetActive(!bCockpit);
}

void AERDVehiclePawn::SelectDestination(int32 Index)
{
	if (UGameInstance* GI = GetGameInstance())
		if (UERDRoutingSubsystem* R = GI->GetSubsystem<UERDRoutingSubsystem>())
			R->StartRouteToDestination(Index);
}
void AERDVehiclePawn::CancelRoute()
{
	if (UGameInstance* GI = GetGameInstance())
		if (UERDRoutingSubsystem* R = GI->GetSubsystem<UERDRoutingSubsystem>())
			R->CancelRoute();
}

// ---------------- Readouts ----------------
float AERDVehiclePawn::GetSpeedKmh() const { const auto* M = Mov(); return M ? FMath::Abs(M->GetForwardSpeed()) * 0.036f : 0.f; } // cm/s -> km/h
float AERDVehiclePawn::GetRPM() const      { const auto* M = Mov(); return M ? M->GetEngineRotationSpeed() : 0.f; }
int32 AERDVehiclePawn::GetGear() const     { const auto* M = Mov(); return M ? M->GetCurrentGear() : 0; }

// ---------------- Tick: fuel + GPS position ----------------
void AERDVehiclePawn::Tick(float Dt)
{
	Super::Tick(Dt);

	// Fuel: idle burn + load-dependent burn
	const float Load = ThrottleInput * FMath::Clamp(GetRPM() / FMath::Max(1.f, MaxRPM), 0.f, 1.f);
	Fuel = FMath::Max(0.f, Fuel - (IdleBurnLPerSec + FullLoadBurnLPerSec * Load) * Dt);
	if (Fuel <= 0.f) if (auto* M = Mov()) M->SetThrottleInput(0.f);

	// Convert world position -> real lon/lat via Cesium georeference, feed the GPS
	PosTimer += Dt;
	if (PosTimer >= 0.25f)
	{
		PosTimer = 0.f;
		if (ACesiumGeoreference* Geo = ACesiumGeoreference::GetDefaultGeoreference(this))
		{
			const FVector LLH = Geo->TransformUnrealPositionToLongitudeLatitudeHeight(GetActorLocation());
			if (UGameInstance* GI = GetGameInstance())
				if (UERDRoutingSubsystem* R = GI->GetSubsystem<UERDRoutingSubsystem>())
					R->UpdatePlayerPosition(LLH.X, LLH.Y);
		}
	}
}

// ---------------- Paint ----------------
void AERDVehiclePawn::SetPaintColor(FLinearColor Color)
{
	CurrentPaint = Color;
	if (USkeletalMeshComponent* Mesh = GetMesh())
	{
		if (UMaterialInstanceDynamic* MID = Mesh->CreateAndSetMaterialInstanceDynamic(PaintMaterialSlot))
			MID->SetVectorParameterValue(PaintParameterName, Color);
	}
}

// ---------------- Save / Load ----------------
void AERDVehiclePawn::SaveProgress()
{
	UERDSaveGame* S = Cast<UERDSaveGame>(UGameplayStatics::CreateSaveGameObject(UERDSaveGame::StaticClass()));
	if (!S) return;

	if (ACesiumGeoreference* Geo = ACesiumGeoreference::GetDefaultGeoreference(this))
	{
		const FVector LLH = Geo->TransformUnrealPositionToLongitudeLatitudeHeight(GetActorLocation());
		S->Lon = LLH.X; S->Lat = LLH.Y; S->Height = LLH.Z;
	}
	S->Yaw = GetActorRotation().Yaw;
	S->Fuel = Fuel;
	S->SelectedCarIndex = SelectedCarIndex;
	S->PaintColor = CurrentPaint;

	if (UGameInstance* GI = GetGameInstance())
		if (UERDRoutingSubsystem* R = GI->GetSubsystem<UERDRoutingSubsystem>())
		{
			S->bHasDestination = R->bHasRoute;
			S->DestName = R->DestinationName;
			if (R->RoutePoints.Num() > 0) { S->DestLon = R->RoutePoints.Last().X; S->DestLat = R->RoutePoints.Last().Y; }
		}
	UGameplayStatics::SaveGameToSlot(S, UERDSaveGame::SlotName(), 0);
}

void AERDVehiclePawn::LoadProgress()
{
	UERDSaveGame* S = Cast<UERDSaveGame>(UGameplayStatics::LoadGameFromSlot(UERDSaveGame::SlotName(), 0));
	if (!S) return;

	if (ACesiumGeoreference* Geo = ACesiumGeoreference::GetDefaultGeoreference(this))
	{
		// +300 cm so the car drops onto the tileset collision instead of spawning inside it
		const FVector P = Geo->TransformLongitudeLatitudeHeightToUnreal(FVector(S->Lon, S->Lat, S->Height + 3.0));
		SetActorLocationAndRotation(P, FRotator(0.f, S->Yaw, 0.f), false, nullptr, ETeleportType::ResetPhysics);
		GetMesh()->SetPhysicsLinearVelocity(FVector::ZeroVector);
		GetMesh()->SetPhysicsAngularVelocityInDegrees(FVector::ZeroVector);
	}
	Fuel = S->Fuel;
	SelectedCarIndex = S->SelectedCarIndex;
	SetPaintColor(S->PaintColor);

	if (S->bHasDestination)
		if (UGameInstance* GI = GetGameInstance())
			if (UERDRoutingSubsystem* R = GI->GetSubsystem<UERDRoutingSubsystem>())
			{
				R->DestinationName = S->DestName;
				R->RequestRoute(R->PlayerLon, R->PlayerLat, S->DestLon, S->DestLat);
			}
}
