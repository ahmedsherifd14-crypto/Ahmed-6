using UnrealBuildTool;
using System.Collections.Generic;

public class EgyptRealDriveEditorTarget : TargetRules
{
	public EgyptRealDriveEditorTarget(TargetInfo Target) : base(Target)
	{
		Type = TargetType.Editor;
		DefaultBuildSettings = BuildSettingsVersion.V5;
		IncludeOrderVersion = EngineIncludeOrderVersion.Latest;
		ExtraModuleNames.Add("EgyptRealDrive");
	}
}
