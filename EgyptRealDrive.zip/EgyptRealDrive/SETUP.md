# Egypt Real Drive – UE5 project (Phase 1 prototype scaffold)

**Status: source code written but NOT compiled or tested** (no Unreal Engine was available where it was written).
Expect a few small compile fixes on first build, mostly engine-version API differences.
Targeted at Unreal Engine 5.5 (change `EngineAssociation` in the .uproject if you use another 5.x).

## What is in this project (real C++, no placeholders)
| File | What it does |
|---|---|
| `ERDVehiclePawn` | Chaos-vehicle car: throttle/brake/steer/handbrake, auto + manual gearbox (T, E/Q), speed km/h, RPM, gear, fuel burn + refuel (R), chase + cockpit camera (C), paint colour, save/load (F5/F9) |
| `ERDRoutingSubsystem` | Real GPS: sends player position + destination to an OSRM server (OpenStreetMap roads), gets the route, tracks progress, distance + ETA, next-turn text, auto re-route when you leave the road |
| `ERDHUD` | Speedometer, RPM bar, gear, fuel, GPS panel (position, next turn, distance, time) and a route mini-map |
| `ERDSaveGame` | Position (as real lon/lat), fuel, paint, destination |
| `ERDGameMode` | Wires pawn + HUD |
| `Config/` | Lumen, Virtual Shadow Maps, Nanite, input mappings |

Destinations on keys 1..9,0: Cairo, Giza, Alexandria, New Cairo, 6th of October, Sharm El Sheikh, Hurghada, Luxor, Aswan, North Coast (El Alamein). X cancels.

## What is NOT included (needs assets / editor work, cannot be generated as text)
- Car 3D models, interiors, sounds, wheel/rim meshes, garage scene, main-menu UMG widgets
- The Egypt level itself (Cesium streams it – steps below)
- Traffic AI, pedestrians, traffic lights, damage deformation (later phases)

## Setup steps
1. Install Unreal Engine 5.5+ and Visual Studio 2022 (Game development with C++ + Windows SDK).
2. Install the **Cesium for Unreal** plugin (Fab / Epic launcher) into the engine. Make a free Cesium ion account and create an access token.
3. Right-click `EgyptRealDrive.uproject` → *Generate Visual Studio project files*, open the .sln, build `EgyptRealDriveEditor` (Development Editor), then launch.
4. New level `Maps/Egypt`. Add **Cesium World Terrain** (+ Bing/other imagery) and **Cesium OSM Buildings** from the Cesium panel. On each tileset enable *Create Physics Meshes* so the car has collision.
5. Select the **CesiumGeoreference** actor and set its origin to New Damietta (approx lon 31.70, lat 31.42) or any city. Put a PlayerStart a little above the ground at the origin.
6. Create the vehicle Blueprint: Content Browser → new Blueprint class from `ERDVehiclePawn` (`BP_ERDVehicle`). Assign skeletal mesh, physics asset, anim BP (Vehicle Animation), and in the Vehicle Movement component add 4 wheels (create 2 Blueprint classes from `ChaosVehicleWheel`: front with steering, rear with handbrake) with your mesh's bone names. Set engine torque curve, gear ratios, mass, suspension per car.
7. Create `BP_ERDGameMode` from `ERDGameMode`, set Default Pawn = `BP_ERDVehicle`, and set it as the level's GameMode override.
8. Play. If the GPS says "Routing service unreachable", check internet.

## Real-road notes (read these)
- `router.project-osrm.org` is a **demo server for testing only**. For a shipped game self-host OSRM with the Egypt extract from Geofabrik (`egypt-latest.osm.pbf`) and set `ServerUrl`.
- Cesium terrain/OSM buildings give real geography, but drivable *road surfaces* come from the imagery/tileset. A cleaner approach in a later phase: download OSM road ways (Overpass / Geofabrik) and generate road splines + intersections + lane data with Python/Houdini/Mass ZoneGraph – this is also what traffic AI needs.
- Google Photorealistic 3D Tiles via Cesium look great, but their terms restrict some uses (e.g. caching, shipping in an app). Check them before a Google Play release.

## Cars and licences
Real brand cars (BMW, Mercedes, Ferrari…) need licences from the manufacturers or from licensed asset vendors. Do not ship downloaded fan models of these brands commercially. For the prototype use any free/placeholder car; for release use licensed assets or original look-alike designs without logos.

## Roadmap
1. (this scaffold) drive + GPS on real Egyptian roads
2. Garage level + UMG menus (Start, Garage, Map, Settings), car selection by spawning different BP children
3. OSM road/intersection import → traffic AI (Mass), traffic lights, signs
4. Egyptian environment kit (buildings, vegetation, desert, props), weather + day/night
5. World Partition tuning for streaming across large areas
